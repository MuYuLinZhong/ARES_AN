package com.infineon.smack.sdk

import android.content.Intent
import androidx.annotation.VisibleForTesting
import androidx.fragment.app.FragmentActivity
import com.infineon.smack.sdk.SmackSdk.Builder
import com.infineon.smack.sdk.android.AndroidNfcAdapterWrapper
import com.infineon.smack.sdk.android.SmackLifecycleObserver
import com.infineon.smack.sdk.application.lock.LockApi
import com.infineon.smack.sdk.application.lock.SmackLockApi
import com.infineon.smack.sdk.application.measurement.MeasurementApi
import com.infineon.smack.sdk.application.measurement.SmackMeasurementApi
import com.infineon.smack.sdk.log.NoOpSmackLogger
import com.infineon.smack.sdk.log.SmackLogger
import com.infineon.smack.sdk.mailbox.MailboxApi
import com.infineon.smack.sdk.mailbox.SmackMailboxApi
import com.infineon.smack.sdk.nfc.NfcAdapterWrapper
import com.infineon.smack.sdk.smack.DefaultSmackApi
import com.infineon.smack.sdk.smack.DefaultSmackClient
import com.infineon.smack.sdk.smack.SmackApi
import com.infineon.smack.sdk.smack.SmackClient
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers

/**
 * This is the entry class for all SmAcK APIs. Use the [Builder] to build a [SmackSdk] instance.
 * Use this [SmackSdk] instance to access the provided fields.
 */
@Suppress("unused", "LongParameterList")
class SmackSdk private constructor(
    val smackClient: SmackClient,
    /** A [SmackApi] instance for external usage */
    @get:VisibleForTesting
    val nfcAdapterWrapper: NfcAdapterWrapper,
    /** A [CoroutineDispatcher] to run all background tasks */
    val coroutineDispatcher: CoroutineDispatcher,
    /** A [SmackClient] including a [SmackLogger] */
    val smackApi: SmackApi,
    /** A [MailboxApi] instance for external usage */
    val mailboxApi: MailboxApi,
    /** A [LockApi] instance for external usage */
    val lockApi: LockApi,
    /** A [MeasurementApi] instance for external usage */
    val measurementApi: MeasurementApi,
) {

    private var lifecycleObserver: SmackLifecycleObserver? = null

    /**
     * If true, [onNewIntent] will process incoming intents, otherwise not.
     */
    var isEnabled: Boolean
        get() = getLifecycleObserver().isEnabled
        set(value) {
            getLifecycleObserver().isEnabled = value
        }

    /**
     * Returns a [SmackLifecycleObserver] for NFC foreground dispatch management.
     *
     * @return a [SmackLifecycleObserver] for NFC foreground dispatch management
     */
    private fun getLifecycleObserver() = lifecycleObserver
        ?: throw IllegalStateException(
            "LifecycleObserver is not initialized. Please call smackSdk.onCreate(activity) " +
                "in your activities onCreate() function."
        )

    /**
     * Adds the [SmackLifecycleObserver] observer to the activities lifecycle,
     * so the NFC foreground dispatch can be enabled and disabled automatically.
     *
     * @param activity a [FragmentActivity] receiving NFC scan intents
     * @param lifecycleObserver a [SmackLifecycleObserver] for NFC foreground dispatch management
     * (optional)
     */
    fun onCreate(activity: FragmentActivity, lifecycleObserver: SmackLifecycleObserver? = null) {
        this.lifecycleObserver = lifecycleObserver ?: createSmackLifecycleObserver(activity)
        activity.lifecycle.addObserver(getLifecycleObserver())
    }

    /**
     * Processes the incoming intent and connects to the enclosed NFC-A tag if possible
     * only if [isEnabled] is true.
     *
     * @param intent the [Intent] from an NFC scan.
     *
     * @see isEnabled
     */
    fun onNewIntent(intent: Intent?) {
        getLifecycleObserver().onNewIntent(intent)
    }

    private fun createSmackLifecycleObserver(activity: FragmentActivity) =
        SmackLifecycleObserver(
            activity,
            smackClient,
            nfcAdapterWrapper,
            coroutineDispatcher
        )

    /**
     * The builder for SmackSdk instances.
     *
     * @param smackClient a [SmackClient] instance including a [SmackLogger]
     * (default: [DefaultSmackClient] with [NoOpSmackLogger])
     * @param nfcAdapterWrapper an [NfcAdapterWrapper] instance
     * for NFC foreground dispatch management (default: [AndroidNfcAdapterWrapper])
     * @param coroutineDispatcher a [CoroutineDispatcher] to run all background tasks (default: [Dispatchers.IO])
     */
    class Builder(
        private var smackClient: SmackClient = DefaultSmackClient(NoOpSmackLogger()),
        private var nfcAdapterWrapper: NfcAdapterWrapper = AndroidNfcAdapterWrapper(),
        private var coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO,
    ) {

        /**
         * Sets a [SmackClient] including a [SmackLogger] to use for all provided API instances. (Optional)
         *
         * @param smackClient a [SmackClient] instance including a [SmackLogger]
         *
         * @return the [Builder] instance
         */
        fun setSmackClient(smackClient: SmackClient) = apply { this.smackClient = smackClient }

        /**
         * Sets an [NfcAdapterWrapper] for NFC foreground dispatch management. (Optional)
         *
         * @param nfcAdapterWrapper an [NfcAdapterWrapper] instance
         * for NFC foreground dispatch management
         *
         * @return the [Builder] instance
         */
        fun setNfcAdapterWrapper(nfcAdapterWrapper: NfcAdapterWrapper) =
            apply { this.nfcAdapterWrapper = nfcAdapterWrapper }

        /**
         * Sets a [CoroutineDispatcher] to run all background tasks. (Optional)
         *
         * @param coroutineDispatcher a [CoroutineDispatcher] to run all background tasks
         *
         * @return the [Builder] instance
         */
        fun setCoroutineDispatcher(coroutineDispatcher: CoroutineDispatcher) =
            apply { this.coroutineDispatcher = coroutineDispatcher }

        /**
         * Builds a new [SmackSdk] instance.
         *
         * @return a new [SmackSdk] instance
         */
        fun build(): SmackSdk {
            val smackApi = DefaultSmackApi(smackClient)
            val mailboxApi = SmackMailboxApi(smackClient, smackApi)
            val lockApi = SmackLockApi(smackClient, mailboxApi)
            val measurementApi = SmackMeasurementApi(smackClient, mailboxApi)
            return SmackSdk(
                smackClient,
                nfcAdapterWrapper,
                coroutineDispatcher,
                smackApi,
                mailboxApi,
                lockApi,
                measurementApi
            )
        }
    }
}
