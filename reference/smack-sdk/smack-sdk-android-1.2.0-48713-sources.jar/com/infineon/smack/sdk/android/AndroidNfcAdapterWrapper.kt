package com.infineon.smack.sdk.android

import android.app.Activity
import android.app.PendingIntent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import com.infineon.smack.sdk.nfc.NfcAdapterWrapper

class AndroidNfcAdapterWrapper : NfcAdapterWrapper {

    override fun enableForegroundDispatch(
        activity: Activity,
        intent: PendingIntent,
        filters: Array<IntentFilter>,
        techLists: Array<Array<String>>
    ) = NfcAdapter.getDefaultAdapter(activity)
        ?.enableForegroundDispatch(activity, intent, filters, techLists)

    override fun disableForegroundDispatch(activity: Activity) =
        NfcAdapter.getDefaultAdapter(activity)?.disableForegroundDispatch(activity)
}
