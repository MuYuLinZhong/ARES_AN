package com.infineon.smack.sdk.android

import android.annotation.SuppressLint
import android.app.PendingIntent
import android.app.PendingIntent.FLAG_MUTABLE
import android.content.Intent
import android.content.IntentFilter
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.Ndef
import android.nfc.tech.NfcA
import android.os.Build
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.infineon.smack.sdk.nfc.NfcAdapterWrapper
import com.infineon.smack.sdk.smack.SmackClient
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * This [LifecycleObserver] enables and disables NFC foreground dispatch
 * automatically in onResume and onPause.
 */
class SmackLifecycleObserver(
    private val activity: FragmentActivity,
    private val smackClient: SmackClient,
    private val nfcAdapterWrapper: NfcAdapterWrapper = AndroidNfcAdapterWrapper(),
    private val coroutineDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : DefaultLifecycleObserver {

    /**
     * If true, [onNewIntent] will process incoming intents, otherwise not.
     */
    var isEnabled: Boolean = true

    override fun onResume(owner: LifecycleOwner) {
        nfcAdapterWrapper.enableForegroundDispatch(
            activity,
            getPendingIntent(),
            arrayOf(IntentFilter(NfcAdapter.ACTION_TECH_DISCOVERED)),
            arrayOf(arrayOf(Ndef::class.java.name))
        )
    }

    override fun onPause(owner: LifecycleOwner) {
        nfcAdapterWrapper.disableForegroundDispatch(activity)
    }

    override fun onCreate(owner: LifecycleOwner) {
        // Empty override because of https://stackoverflow.com/a/60873211/345810
    }

    override fun onStart(owner: LifecycleOwner) {
        // Empty override because of https://stackoverflow.com/a/60873211/345810
    }

    override fun onStop(owner: LifecycleOwner) {
        // Empty override because of https://stackoverflow.com/a/60873211/345810
    }

    override fun onDestroy(owner: LifecycleOwner) {
        // Empty override because of https://stackoverflow.com/a/60873211/345810
    }

    /**
     * Processes the incoming intent and connects to the enclosed NFC-A tag if possible
     * only if [isEnabled] is true.
     *
     * @param intent the [Intent] from an NFC scan.
     *
     * @see isEnabled
     */
    fun onNewIntent(intent: Intent?) {
        if (isEnabled) {
            intent?.getNfcA()?.let { nfcA ->
                activity.lifecycleScope.launch(coroutineDispatcher) {
                    smackClient.onNewConnection(NfcAConnection(nfcA, smackClient.nfcLogger))
                }
            }
        }
    }

    @SuppressLint("UnspecifiedImmutableFlag")
    private fun getPendingIntent(): PendingIntent {
        val intent = Intent(activity, activity.javaClass)
        intent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(
            activity,
            0,
            intent,
            getPendingIntentFlags()
        )
    }

    private fun getPendingIntentFlags(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_UPDATE_CURRENT or FLAG_MUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
    }

    private fun Intent.getNfcA(): NfcA? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)?.let { tag -> NfcA.get(tag) }
        } else {
            @Suppress("DEPRECATION")
            getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG)?.let { tag -> NfcA.get(tag) }
        }
    }
}
