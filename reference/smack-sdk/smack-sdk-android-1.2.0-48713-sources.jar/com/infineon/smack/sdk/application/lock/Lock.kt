package com.infineon.smack.sdk.application.lock

import com.infineon.smack.sdk.mailbox.SmackMailbox

/**
 * The Lock holds a mailbox and the lock id.
 */
data class Lock(
    /** The [SmackMailbox] that is used internally to communicate with the lock. **/
    val mailbox: SmackMailbox,
    /** A unique id for this lock **/
    val lockId: Long,
    /** isNew is only true if no lockKey was ever set before **/
    val isNew: Boolean
)
