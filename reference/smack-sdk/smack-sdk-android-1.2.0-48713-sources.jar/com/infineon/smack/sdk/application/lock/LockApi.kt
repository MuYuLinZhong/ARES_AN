package com.infineon.smack.sdk.application.lock

import com.infineon.smack.sdk.application.lock.datapoint.SessionType
import com.infineon.smack.sdk.application.lock.exception.LockIdValidationException
import com.infineon.smack.sdk.application.lock.history.HistoryItem
import com.infineon.smack.sdk.application.lock.key.LockKey
import com.infineon.smack.sdk.application.lock.motorcontrol.MotorControlParameters
import com.infineon.smack.sdk.mailbox.exception.WrongKeyException
import com.infineon.smack.sdk.smack.charge.ChargeLevel
import kotlinx.coroutines.flow.Flow

/**
 * The [LockApi] is the main entry point for communication with SmAcK NFC locks.
 *
 * [SmackLockApi] is an example implementation of lock functions based on a specification
 * defined by Infineon, i.e. work flow, datapoint definition, key management.
 * It works only with a lock design which has the corresponding showcase firmware installed in NAC1080!
 *
 * If you implemented your own Smart Lock Firmware, you can provide your own implementation of LockApi.
 *
 * **How-To-Use:**
 *
 * Observe the lock [Flow] and map it to your ViewState as needed.
 *
 * Before you can perform any actions on the [Lock], you need to authenticate by calling [LockApi.initializeSession].
 *
 * Then you can use LockApi with the [Lock] to read lock information or lock and unlock the Lock
 * ([getChargeLevel], [lock], [unlock], [getHistory])
 *
 * @see [com.infineon.smack.sdk.application.lock.SmackLockApi]
 */
@Suppress("TooManyFunctions")
interface LockApi {

    /** The [Flow] containing the [Lock] for use with this LockApi */
    fun getLock(): Flow<Lock?>

    /**
     * Registers a new lock key on a brand new lock.
     *
     * @param lock the [Lock] where to set the [LockKey]
     * @param userName Name of the Lock-User. May be up to 40 bytes long (after decoding with UTF-8)
     * @param dateTimeInSeconds The current date and time in seconds since 01.01.1970 (Epoch)
     * @param supervisorKey the ASCII encoded supervisor key must contain exactly 16 characters
     * (included in the locks original packaging)
     * @param password the ASCII encoded lock password to use (maximum length: 16 characters)
     *
     * @throws IllegalArgumentException if the user name is too long
     * @throws IllegalArgumentException if the password or the supervisor key is too long
     * @throws WrongKeyException when the firmware does not know the provided supervisor key
     * @throws LockIdValidationException if the lock id validation fails
     */
    suspend fun setLockKey(
        lock: Lock,
        userName: String,
        dateTimeInSeconds: Long,
        supervisorKey: String,
        password: String
    ): LockKey

    /**
     * Initializes the Session by choosing the session type [SessionType.USER] and sets all
     * information for Lock History.
     * In every session this must be called before [LockApi.lock] or [LockApi.unlock].
     *
     * Please note: For setting the session type [SessionType.SUPERVISOR] and registering a new lock key,
     * you will need to use the method [LockApi.setLockKey].
     *
     * @param lock the lock one wants to interact with
     * @param userName name of the lock user. May be up to 40 characters long
     * @param dateTimeInSeconds the current date and time in seconds since 01.01.1970 (Epoch)
     * @param lockKey the key for authentication
     *
     * @throws IllegalArgumentException if the user name is too long
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun initializeSession(
        lock: Lock,
        userName: String,
        dateTimeInSeconds: Long,
        lockKey: LockKey
    )

    /**
     * Validates the password by converting the password into a lock key and calling [initializeSession] with it.
     *
     * @param lock the lock one wants to interact with
     * @param userName name of the lock user. May be up to 40 characters long
     * @param dateTimeInSeconds the current date and time in seconds since 01.01.1970 (Epoch)
     * @param password the password for authentication
     *
     * @return if the password was correct, the valid lock key is returned and can be stored for later use.
     *
     * @throws WrongKeyException when the password was wrong
     * @throws IllegalArgumentException when the password was invalid (for example too long)
     */
    suspend fun validatePassword(
        lock: Lock,
        userName: String,
        dateTimeInSeconds: Long,
        password: String,
    ): LockKey

    /**
     * Requests the firmware name as an ASCII String.
     *
     * @param lock the desired lock
     * @param lockKey the lock key
     *
     * @return the firmware name
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getFirmwareName(
        lock: Lock,
        lockKey: LockKey
    ): String

    /**
     * Requests the firmware version as a String.
     *
     * @param lock the desired lock
     * @param lockKey the lock key
     *
     * @return the firmware version
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getFirmwareVersion(
        lock: Lock,
        lockKey: LockKey
    ): String

    /**
     * Requests the [ChargeLevel] using the information of a [Lock].
     *
     * Make sure to call [LockApi.initializeSession] before this command.
     *
     * @param lock the desired lock
     * @param lockKey the lock key
     *
     * @return the current [ChargeLevel] of the given [Lock]
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getChargeLevel(
        lock: Lock,
        lockKey: LockKey
    ): ChargeLevel

    /**
     * Sends a request to the [Lock] to lock itself.
     * Make sure to call [LockApi.initializeSession] before this command,
     * otherwise the lock can not save a lock history entry.
     *
     * @param lock the lock to control
     * @param lockKey the corresponding lock key for encryption and decryption
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun lock(lock: Lock, lockKey: LockKey)

    /**
     * Sends a request to the [Lock] to unlock itself.
     * Make sure to call [LockApi.initializeSession] before this command,
     * otherwise the lock can not save a lock history entry.
     *
     * @param lock the lock to control
     * @param lockKey the corresponding lock key for encryption and decryption
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun unlock(lock: Lock, lockKey: LockKey)

    /**
     * Queries the [Lock]'s access logs.
     *
     * Make sure to call [LockApi.initializeSession] before this command.
     *
     * @param lock the connected lock
     * @param lockKey the corresponding lock key for encryption and decryption
     *
     * @return last 10 [HistoryItem]s
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getHistory(
        lock: Lock,
        lockKey: LockKey
    ): List<HistoryItem>

    /**
     * Writes the given motor control parameters to the lock.
     *
     * @param lock the connected lock
     * @param parameters the motor control parameters
     * @param lockKey the corresponding lock key for encryption and decryption
     *
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun writeMotorControlParameters(
        lock: Lock,
        parameters: MotorControlParameters,
        lockKey: LockKey
    )
}
