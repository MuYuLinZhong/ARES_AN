package com.infineon.smack.sdk.application.lock.datapoint

/**
 * These are the values to write in the data points [LockDataPoint.ARM] and [LockDataPoint.CONTROL].
 */
enum class LockControl(val value: ByteArray) {

    /** Unlocks the lock */
    UNLOCK(1),
    /** Locks the lock */
    LOCK(2);

    constructor(value: Byte) : this(byteArrayOf(value))
}
