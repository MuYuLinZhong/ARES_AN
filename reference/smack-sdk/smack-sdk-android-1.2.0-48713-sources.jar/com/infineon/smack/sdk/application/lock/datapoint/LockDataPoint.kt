package com.infineon.smack.sdk.application.lock.datapoint

import com.infineon.smack.sdk.application.lock.history.HistoryItemType
import com.infineon.smack.sdk.mailbox.datapoint.DataPoint
import com.infineon.smack.sdk.mailbox.datapoint.DataPointType
import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.halfWordToUShort

/**
 * [DataPoint]s related to lock hardware.
 */
@Suppress("unused")
enum class LockDataPoint(
    override val value: UShort,
    override val dataType: DataPointType
) : DataPoint {

    /** Requests the lock id. */
    LOCK_ID(byteArrayOf(0x00.toByte(), 0x05.toByte()).halfWordToUShort(), DataPointType.UINT64),

    /**
     * Sets a new lock key for a brand new lock.
     * The session must be initialized with a supervisor key with the supervisor session mode.
     * After setting a new lock key, it must be validated via [LOCK_KEY_CHECK]
     * and stored with [LOCK_KEY_STORE] if valid.
     *
     * @see LOCK_KEY_CHECK
     * @see LOCK_KEY_STORE
     */
    LOCK_KEY(byteArrayOf(0x19.toByte(), 0x02.toByte()).halfWordToUShort(), DataPointType.ARRAY),

    /**
     * Requests the lock ID encrypted with the newly set lock key for validation.
     * The session must be initialized with a supervisor key with the [SessionType.SUPERVISOR].
     * After validating the lock ID, the newly set lock key can be stored in the lock
     * by writing [LOCK_KEY_STORE].
     *
     * NOTE: The communication is encrypted with the supervisor key
     * but the lock ID is encrypted a second time with the newly set lock key.
     * As the lock ID is 64 bit long and the returned array is a 128 bit block,
     * the lock ID is contained twice in the response.
     *
     * @see LOCK_KEY
     * @see LOCK_KEY_STORE
     */
    LOCK_KEY_CHECK(
        byteArrayOf(0x19.toByte(), 0x03.toByte()).halfWordToUShort(),
        DataPointType.ARRAY
    ),

    /**
     * Stores the newly set lock key in the lock for further usage.
     * All communication in future session will be encrypted with the newly set lock key.
     * Future session must be initialized with the newly set lock key and the [SessionType.USER].
     *
     * Value to write:
     * The only allowed value to write is [LockKeyStoreCommand.value].
     * Any other written value has no effect.
     */
    LOCK_KEY_STORE(
        byteArrayOf(0x19.toByte(), 0x01.toByte()).halfWordToUShort(),
        DataPointType.UINT32
    ),

    /**
     * Requests the lock status.
     *
     * Meaning of the returned values:
     * * 0: unlocked
     * * 1: locked
     * * 2: in progress
     * * 7: error occurred
     */
    STATUS(byteArrayOf(0x00, 0x20.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /** Requests the progress of locking/unlocking in percent. */
    CONTROL_PROGRESS(byteArrayOf(0x00, 0x21.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /**
     * Locks of unlocks the lock according to the written [LockControl] value.
     * Before locking or unlocking the [ARM] data point must be written,
     * otherwise writing this data point will be ignored
     * and no action will be performed by the hardware.
     * @see LockControl
     */
    CONTROL(byteArrayOf(0x01.toByte(), 0x20.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /**
     * Arms the lock for locking or unlocking according to the written [LockControl] value.
     * This data point must be written before writing the [CONTROL] data point.
     * @see CONTROL
     */
    ARM(byteArrayOf(0x01.toByte(), 0x21.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /**
     * Requests the number of saved history entries
     */
    LOG_COUNT(byteArrayOf(0x18.toByte(), 0x10.toByte()).halfWordToUShort(), DataPointType.UINT16),

    /**
     * Requests the lock to write one history entry to the mailbox.
     * * 0 is the latest entry
     * * n -1 is the oldest entry.
     * * The DataPoint [LOG_COUNT] can be used to find out n (the number of history entries)
     * * Each history item can then be read from the three [LockDataPoint]: LOG_STATUS, LOG_DATE, LOG_USER
     * @see LOG_COUNT
     * @see LOG_STATUS
     * @see LOG_DATE
     * @see LOG_USER
     */
    LOG_SELECT(byteArrayOf(0x18.toByte(), 0x11.toByte()).halfWordToUShort(), DataPointType.UINT16),

    /**
     * Requests the Type of the History Entry.
     *
     * * Meaning of the returned values:
     * * Bit 0: unlocked
     * * Bit 1: locked
     * * Bit 24: changed lock key
     * @see LOG_SELECT
     * @see HistoryItemType
     */
    LOG_STATUS(byteArrayOf(0x18.toByte(), 0x12.toByte()).halfWordToUShort(), DataPointType.UINT32),

    /**
     * Requests the Date of the History Entry
     *
     *  @see LOG_SELECT
     */
    LOG_DATE(byteArrayOf(0x18.toByte(), 0x13.toByte()).halfWordToUShort(), DataPointType.INT64),

    /**
     * Requests the User of the History Entry
     *
     *  @see LOG_SELECT
     */
    LOG_USER(byteArrayOf(0x18.toByte(), 0x14.toByte()).halfWordToUShort(), DataPointType.STRING),

    /**
     * Sets the data for the next action.
     * This data point must be written together with the [USER_NAME] data point
     * in order to initialize a session.
     */
    DATE(byteArrayOf(0x18.toByte(), 0x00.toByte()).halfWordToUShort(), DataPointType.INT64),

    /**
     * Sets the user name for the next action.
     * This data point must be written together with the [DATE] data point
     * in order to initialize a session.
     */
    USER_NAME(byteArrayOf(0x18.toByte(), 0x01.toByte()).halfWordToUShort(), DataPointType.STRING),

    /**
     * Requests the lock encryption status.
     *
     * @see UserCount
     */
    USER_COUNT(byteArrayOf(0x00.toByte(), 0x30.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /**
     * Sets a [SessionType] for the communication.
     * This defines which type of key will be used during the session.
     *
     */
    USER_SELECT(byteArrayOf(0x19.toByte(), 0x00.toByte()).halfWordToUShort(), DataPointType.UINT8),
}
