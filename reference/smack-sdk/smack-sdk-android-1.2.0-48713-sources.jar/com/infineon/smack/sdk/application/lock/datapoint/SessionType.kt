package com.infineon.smack.sdk.application.lock.datapoint

/**
 * These are the values to write into the data point [LockDataPoint.USER_SELECT].
 */
enum class SessionType(val value: ByteArray) {

    /** For normal users. Using a lock key for authentication  */
    USER(0x01.toByte()),

    /** For supervisors. Using the supervisor key for authentication. This mode is only for registering new lock keys */
    SUPERVISOR(0xfe.toByte());

    constructor(value: Byte) : this(byteArrayOf(value))
}
