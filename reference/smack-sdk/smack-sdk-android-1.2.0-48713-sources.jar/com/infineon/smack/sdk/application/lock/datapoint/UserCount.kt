package com.infineon.smack.sdk.application.lock.datapoint

import androidx.annotation.VisibleForTesting
import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.toByte

/**
 * This is a wrapper for the result of the data point [LockDataPoint.USER_COUNT].
 * Use [UserCount.isNewLock] to check if there already was a lock key registered on this lock or not.
 */
data class UserCount(val value: Byte) {

    /**
     * Interprets the answer of data point [LockDataPoint.USER_COUNT]
     *
     * @return true if no lock key was set before
     * @return false if a lock key was already registered with a valid supervisor key
     */
    fun isNewLock(): Boolean = value == NEW_LOCK_VALUE

    companion object {

        @VisibleForTesting
        const val NEW_LOCK_VALUE = 0x00.toByte()

        /**
         * Helper method to create a UserCount directly from the response byte array
         */
        fun ByteArray.toUserCount() = UserCount(this.toByte())
    }
}
