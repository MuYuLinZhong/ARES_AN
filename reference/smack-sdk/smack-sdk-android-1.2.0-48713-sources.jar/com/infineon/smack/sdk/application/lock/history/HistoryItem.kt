package com.infineon.smack.sdk.application.lock.history

/**
 * HistoryItems reflect the last access to the lock.
 * @property timestamp Date and time of when the access happened in seconds since 1.1.1970 00:00
 * @property userName The name that was transmitted in the lock/unlock command
 * @property type Lock/Unlock [HistoryItemType] Enum
 */
data class HistoryItem(val timestamp: Long, val userName: String, val type: HistoryItemType)
