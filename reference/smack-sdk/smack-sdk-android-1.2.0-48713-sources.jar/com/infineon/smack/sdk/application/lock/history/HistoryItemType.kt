package com.infineon.smack.sdk.application.lock.history

import com.infineon.smack.sdk.application.lock.datapoint.LockDataPoint.LOG_STATUS
import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.wordToInt32

/**
 * Enum that defines what type of operation was performed for the [HistoryItem]
 */
enum class HistoryItemType {
    UNLOCK,
    LOCK,
    CHANGE_KEY;

    companion object {
        /**
         * Helper method to parse a HistoryItemType from a LOG_STATUS-Response.
         *
         * @see LOG_STATUS
         */
        fun fromLogStatus(byteArray: ByteArray): HistoryItemType {
            return when (byteArray.wordToInt32()) {
                1 -> UNLOCK
                2 -> LOCK
                else -> CHANGE_KEY
            }
        }
    }
}
