package com.infineon.smack.sdk.application.lock.motorcontrol

import com.infineon.smack.sdk.application.lock.LockApi

/**
 * The clamping voltage is used as a motor control parameter.
 *
 * @See LockApi.writeMotorControlParameters
 */
@Suppress("unused")
enum class ClampingVoltage(val milliVolt: UShort) {

    /** Low clamping voltage of 3000 mV */
    LOW(3000u),

    /** Medium clamping voltage of 3300 mV */
    MEDIUM(3300u),

    /** High clamping voltage of 3600 mV */
    HIGH(3600u),
}
