package com.infineon.smack.sdk.application.lock.motorcontrol

/**
 * The ConfigMethod is a motor parameter.
 *
 * The ConfigMethod holds the values for the configuration of the operating mode of the lock motor:
 *
 * Depending on the design of the hardware of a lock, different variants of the control
 * of the motor are used. Each of the variants offers different parameters for influencing
 * the motor control, for example a time specification which influences the angle of rotation.
 *
 * @see MotorControlDataPoint.CONFIG_METHOD
 */
@Suppress("MagicNumber")
enum class ConfigMethod(val value: Byte) {

    /** Single step control (time-controlled) */
    SINGLE_STEP_CONTROL(1),

    /** Stepwise control (voltage-controlled) */
    STEPWISE_VOLTAGE_CONTROLLED(2),

    /** Stepwise control (time-controlled) */
    STEPWISE_TIMER_CONTROLLED(3);

    val valueArray: ByteArray = byteArrayOf(value)
}
