package com.infineon.smack.sdk.application.lock.motorcontrol

import com.infineon.smack.sdk.mailbox.datapoint.DataPoint
import com.infineon.smack.sdk.mailbox.datapoint.DataPointType
import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.halfWordToUShort

/**
 * This data points represent various motor control parameters that can be read from or written
 * to the lock to change the motor behavior.
 */
enum class MotorControlDataPoint(
    override val value: UShort,
    override val dataType: DataPointType
) : DataPoint {

    /**
     * Reads or writes the configuration of the operating mode of the lock motor:
     *
     * Depending on the design of the hardware of a lock, different variants of the control
     * of the motor are used. Each of the variants offers different parameters for influencing
     * the motor control, for example a time specification which influences the angle of rotation.
     *
     * @see ConfigMethod for possible values
     */
    CONFIG_METHOD(
        byteArrayOf(0x10.toByte(), 0x00.toByte()).halfWordToUShort(),
        DataPointType.UINT8
    ),

    /**
     * Reads or writes the voltage limitation for charging the energy storage device.
     *
     * @see ClampingVoltage for possible values
     */
    CLAMPING_VOLTAGE(
        byteArrayOf(0x10.toByte(), 0x01.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the upper threshold of the voltage in the energy storage device.
     * When it is reached, the motor can be switched on.
     * The related value is interpreted as millivolt.
     */
    VOLTAGE_CONTROLLED_START_VOLTAGE(
        byteArrayOf(0x10.toByte(), 0x02.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the lower threshold of the voltage in the energy store,
     * below which the motor is switched off in order to be able to fill the energy store again.
     * This voltage should be above the value at which the motor comes to a standstill.
     * The related value is interpreted as millivolt.
     */
    VOLTAGE_CONTROLLED_STOP_VOLTAGE(
        byteArrayOf(0x10.toByte(), 0x03.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the period of time with time-controlled stepwise motor control
     * for which the motor is switched on. This time span should be chosen so that the motor can be
     * safely supplied from the energy store during this time.
     * The related value is interpreted as milliseconds.
     */
    TIMER_CONTROLLED_ON_TIME(
        byteArrayOf(0x10.toByte(), 0x04.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the period of time with time-controlled stepwise motor control
     * for which the motor remains switched off in order to charge the energy storage device.
     * This period of time should be chosen so that the energy storage device can be recharged
     * even with a moderate NFC field strength.
     * The related value is interpreted as milliseconds.
     */
    TIMER_CONTROLLED_OFF_TIME(
        byteArrayOf(0x10.toByte(), 0x05.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the upper threshold of the voltage in the energy storage device.
     * When reached, the motor can be switched on in the “one-time switch-on” mode (millivolt).
     * This voltage should be below the voltage limit for charging the energy store
     * with sufficient tolerance.
     * The related value is interpreted as millivolt.
     */
    SINGLE_MOVEMENT_START_VOLTAGE(
        byteArrayOf(0x10.toByte(), 0x06.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /**
     * Reads or writes the total runtime of the motor. This is the net time the motor is switched on
     * to perform a lock or unlock operation. The overall time span may be longer than the runtime
     * configured here if a stepwise method is selected, as the stepwise method incorporates breaks
     * without motor movement between the steps.
     * The related value is interpreted as milliseconds.
     */
    TOTAL_MOTOR_RUNTIME(
        byteArrayOf(0x10.toByte(), 0x07.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),
}
