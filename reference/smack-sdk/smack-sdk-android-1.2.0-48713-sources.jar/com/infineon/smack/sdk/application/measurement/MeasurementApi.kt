package com.infineon.smack.sdk.application.measurement

import com.infineon.smack.sdk.mailbox.SmackMailbox
import kotlinx.coroutines.flow.Flow

/**
 * The [MeasurementApi] is the main entry point for communication with SmAcK NFC measurement hardware.
 *
 * [SmackMeasurementApi] is an example implementation of measurement functions based on a specification
 * defined by Infineon, i.e. work flow, datapoint definition, key management.
 * It works only with a lock design which has the corresponding showcase firmware installed in NAC1080!
 *
 *If you implemented your own Measurement Firmware, you can provide your own implementation of MeasurementApi.
 *
 * **How-to-use:**
 * Observe the mailbox [Flow] and map it to your ViewState as needed.
 * Use MeasurementApi with the [SmackMailbox] to request measurement values.
 */
interface MeasurementApi {

    /**
     * Requests the temperature value in °C.
     *
     * @param mailbox the [SmackMailbox] to communicate with
     *
     * @return the temperature value in °C
     */
    suspend fun getTemperature(mailbox: SmackMailbox): Float

    /**
     * Requests the relative humidity value in percent.
     *
     * @param mailbox the [SmackMailbox] to communicate with
     *
     * @return the humidity value in percent
     */
    suspend fun getHumidity(mailbox: SmackMailbox): Float

    /**
     * Requests the pressure value in bar.
     *
     * @param mailbox the [SmackMailbox] to communicate with
     *
     * @return the temperature value
     */
    suspend fun getPressure(mailbox: SmackMailbox): Float

    /**
     * Requests the value reserved for future use.
     *
     * @param mailbox the [SmackMailbox] to communicate with
     *
     * @return the value reserved for future use
     */
    suspend fun getReserved(mailbox: SmackMailbox): Int
}
