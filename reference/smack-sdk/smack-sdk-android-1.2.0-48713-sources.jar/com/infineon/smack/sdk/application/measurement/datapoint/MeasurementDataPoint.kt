package com.infineon.smack.sdk.application.measurement.datapoint

import com.infineon.smack.sdk.mailbox.datapoint.DataPoint
import com.infineon.smack.sdk.mailbox.datapoint.DataPointType
import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.halfWordToUShort

/**
 * [DataPoint]s related to measurement of physical quantities.
 */
enum class MeasurementDataPoint(
    override val value: UShort,
    override val dataType: DataPointType,
    val scale: Float = 1f,
    val decimals: Int = 0
) : DataPoint {

    /**
     * Temperature
     * Resolution: 0.1 °C
     * Display: one decimal point
     */
    TEMPERATURE(
        byteArrayOf(0x00.toByte(), 0x80.toByte()).halfWordToUShort(),
        DataPointType.INT16,
        scale = 0.1f,
        decimals = 1
    ),

    /**
     * Humidity
     * Resolution: 0.1 %
     * Display: one decimal point
     */
    HUMIDITY(
        byteArrayOf(0x00.toByte(), 0x81.toByte()).halfWordToUShort(),
        DataPointType.INT16,
        scale = 0.1f,
        decimals = 1
    ),

    /**
     * Pressure
     * Resolution: 0.001 bar (1 mbar, 1 hPa)
     * Display: two decimal point (unit "bar")
     */
    PRESSURE(
        byteArrayOf(0x00.toByte(), 0x82.toByte()).halfWordToUShort(),
        DataPointType.INT16,
        scale = 0.001f,
        decimals = 3
    ),

    /**
     * Reserved for future use
     * Resolution: 1 digit
     * Display: Integer (as is)
     */
    RESERVED(byteArrayOf(0x00.toByte(), 0x83.toByte()).halfWordToUShort(), DataPointType.INT32),
}
