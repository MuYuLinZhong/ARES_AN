package com.infineon.smack.sdk.log

import android.util.Log

class AndroidSmackLogger : SmackLogger {

    override fun log(level: LogLevel, message: String, exception: Throwable?) {
        when (level) {
            LogLevel.ERROR -> Log.e(TAG, message, exception)
            LogLevel.INFO -> Log.i(TAG, message, exception)
            LogLevel.DEBUG -> Log.d(TAG, message, exception)
            LogLevel.VERBOSE -> Log.v(TAG, message, exception)
        }
    }

    companion object {
        private const val TAG = "SmAck"
    }
}
