package com.infineon.smack.sdk.log

/**
 * Log Level that is used for the SmackLogger
 * @see ERROR
 * @see INFO
 * @see DEBUG
 * @see VERBOSE
 */
enum class LogLevel {
    /** For exceptions and errors */
    ERROR,

    /** For high level calls like writeDataPoint/readDataPoint */
    INFO,

    /** For low level information about sent and received byte arrays */
    DEBUG,

    /** For additional information around the above levels */
    VERBOSE,
}
