package com.infineon.smack.sdk.log

/**
 * SmackLogger is an interface for logging messages.
 *
 * @see LogLevel
 */
interface SmackLogger {

    /**
     * Logs the given message.
     *
     * @param level see [LogLevel]
     * @param message the message to log
     * @param exception optional exception to print stacktraces
     */
    fun log(level: LogLevel, message: String, exception: Throwable? = null)

    /**
     * Logs the given message with level [LogLevel.VERBOSE].
     * For additional information around the higher levels.
     *
     * Calls [SmackLogger.log] in default implementation.
     *
     * @param message the message to log
     *
     */
    fun logVerbose(message: String) = log(LogLevel.VERBOSE, message)

    /**
     * Logs the given message with level [LogLevel.DEBUG].
     * For low level information about sent and received byte arrays.
     *
     * Calls [SmackLogger.log] in default implementation.
     *
     * @param message the message to log
     *
     */
    fun logDebug(message: String) = log(LogLevel.DEBUG, message)

    /**
     * Logs the given message with level [LogLevel.INFO].
     * For high level calls like writeDataPoint/readDataPoint.
     *
     * Calls [SmackLogger.log] in default implementation.
     *
     * @param message the message to log
     *
     */
    fun logInfo(message: String) = log(LogLevel.INFO, message)

    /**
     * Logs the given message with level [LogLevel.ERROR].
     * For exceptions and errors.
     *
     * Calls [SmackLogger.log] in default implementation.
     *
     * @param message the message to log. This function adds "ERROR" + exception name + exception message as prefix to the message
     * @param exception exception to print exception name, message and if needed stacktraces
     *
     */
    fun logError(message: String? = "", exception: Throwable) = log(
        level = LogLevel.ERROR,
        message = "ERROR: ${exception.javaClass.simpleName}: ${exception.message} -> $message",
        exception = exception
    )
}
