package com.infineon.smack.sdk.mailbox

/**
 * These are the header flags used in the word at index 1 (last two bytes).
 */
@Suppress("unused")
enum class HeaderFlag(val value: UShort) {

    /**
     * Indicating a valid request.
     * Must be set in order for the hardware to process the mailbox contents.
     */
    REQUEST_VALID(1u),

    /** Set, if data was written to a tag. */
    WRITE_REQUEST(2u),

    /** Is set, if the response in the mailbox contents is valid. */
    RESPONSE_VALID(4u),

    /**
     * Error bit set, if the hardware couldn't process the mailbox contents
     * (e.g. the contents couldn't be decrypted).
     */
    ERROR_INVALID_DATA(8u),

    /** Error bit set, if the requested data point (from word at index 3) is not defined. */
    ERROR_DATA_POINT_NOT_DEFINED(16u),

    /**
     * Error bit set, if the requested data point type (from word at index 3)
     * doesn't match the data type associated with the requested data point on the hardware side.
     */
    ERROR_DATA_POINT_TYPE_MISMATCH(32u),

    /** Error bit set, if the requested data point is write protected. */
    ERROR_WRITE_PROTECTED(64u),

    /** Reserved for future features */
    ALERT(16384u),

    /** Indicated the the payload (words at indices 2 to n) is encrypted. */
    PAYLOAD_IS_ENCRYPTED(32768u);

    private fun isBitwiseSet(flags: UShort) = flags and value != 0.toUShort()

    companion object {

        /**
         * ORs bitwise all given header flags to one UShort.
         *
         * @param flags the flags to bitwise OR
         *
         * @return the resulting UShort
         */
        fun bitwiseOr(vararg flags: HeaderFlag) =
            flags.map { it.value }.fold(0u.toUShort()) { a, b -> a or b }

        /**
         * Checks if the [RESPONSE_VALID] flag is set in the given flags.
         *
         * @param flags the flags to check
         *
         * @return true, if the [RESPONSE_VALID] flag is set, otherwise false
         */
        fun isResponseValid(flags: UShort) = RESPONSE_VALID.isBitwiseSet(flags)

        /**
         * Checks if the [PAYLOAD_IS_ENCRYPTED] flag is set in the given flags.
         *
         * @param flags the flags to check
         *
         * @return true, if the [PAYLOAD_IS_ENCRYPTED] flag is set, otherwise false
         */
        fun isEncrypted(flags: UShort) = PAYLOAD_IS_ENCRYPTED.isBitwiseSet(flags)

        /**
         * Returns all [HeaderFlag]s set in the given flags as a list
         *
         * @param flags the flags to spread
         *
         * @return all [HeaderFlag]s set in the given flags as a list
         */
        fun findMatching(flags: UShort) = values().filter {
            it.isBitwiseSet(flags)
        }
    }
}
