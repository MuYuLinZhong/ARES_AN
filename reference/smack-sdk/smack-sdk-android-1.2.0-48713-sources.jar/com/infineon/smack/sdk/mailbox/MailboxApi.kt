package com.infineon.smack.sdk.mailbox

import com.infineon.smack.sdk.application.lock.key.LockKey
import com.infineon.smack.sdk.mailbox.datapoint.DataPoint
import com.infineon.smack.sdk.mailbox.datapoint.DataPointType
import com.infineon.smack.sdk.mailbox.exception.HeaderValidationException
import com.infineon.smack.sdk.mailbox.exception.MailboxMessageValidResponseException
import com.infineon.smack.sdk.mailbox.exception.SmackMailboxException
import com.infineon.smack.sdk.mailbox.exception.WrongKeyException
import com.infineon.smack.sdk.smack.charge.ChargeLevel
import com.infineon.smack.sdk.smack.exception.DataValidationException
import com.infineon.smack.sdk.smack.exception.ProtocolException
import com.infineon.smack.sdk.smack.exception.ResponseException
import com.infineon.smack.sdk.smack.request.MailboxMessageValidRequest
import com.infineon.smack.sdk.smack.response.SmackResponse
import kotlinx.coroutines.flow.Flow
import java.security.InvalidKeyException

/**
 * The MailboxApi is the main entry point for generic communication with SmAcK NFC hardware using
 * using [DataPoint].
 *
 * Observe the mailbox [Flow] and map it to your ViewState as needed.
 * Use MailboxApi with the [SmackMailbox] to read or write single words ([readWord], [writeWord])
 * or [DataPoint]s ([readDataPoint], [writeDataPoint]).
 */
interface MailboxApi {

    /** The [Flow] containing the [SmackMailbox] for use with this MailboxApi */
    val mailbox: Flow<SmackMailbox?>

    /**
     * Reads the word (4 Bytes) from the mailbox at the address of the word at the given index.
     *
     * @param mailbox the [SmackMailbox] for the word address calculation
     * @param index the index of the word to read
     *
     * @return the read word (4 Bytes)
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws ProtocolException if the word couldn't be read
     * @throws SmackMailboxException if the word address can't be calculated
     * @throws ResponseException if the validation fails
     */
    suspend fun readWord(mailbox: SmackMailbox, index: Int): ByteArray

    /**
     * Writes the given word (4 Bytes) into the mailbox
     * at the address of the word at the given index.
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     * @param word the four byte [ByteArray] to send
     * @param index the index of the word to write
     *
     * @return the [SmackResponse] from writing the word
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws ProtocolException if the word couldn't be written
     * @throws SmackMailboxException if the word address can't be calculated
     * @throws ResponseException if the validation fails
     */
    suspend fun writeWord(mailbox: SmackMailbox, word: ByteArray, index: Int): SmackResponse

    /**
     * Reads the data from the given [DataPoint].
     * Reading from a [DataPoint] means writing a bunch of words into the mailbox,
     * sending a [MailboxMessageValidRequest] and reading the requested data from the mailbox.
     *
     * @param mailbox the [SmackMailbox] for the word address calculation
     * @param dataPoint the [DataPoint] to read the data from
     * @param bufferSize the size of the receiver buffer (mandatory for [DataPointType.STRING]
     * and [DataPointType.ARRAY])
     * @param encryptionDecryptionKey the AES key for data encryption and decryption
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws InvalidKeyException if the given encryptionDecryptionKey is not 16 Bytes long.
     * Only AES128 is supported.
     * @throws ProtocolException if the data couldn't be read from the [DataPoint]
     * or if the read data was shorter than the expected data length
     * @throws IllegalArgumentException if a [DataPoint] with [DataPointType] [DataPointType.STRING]
     * or [DataPointType.ARRAY] is read without providing the length of the data to read
     * or if the provided dynamicDataToReadLength is 0
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun readDataPoint(
        mailbox: SmackMailbox,
        dataPoint: DataPoint,
        bufferSize: Byte? = null,
        encryptionDecryptionKey: LockKey? = null
    ): ByteArray

    /**
     * Writes the given data to the given [DataPoint].
     * Writing to a [DataPoint] means writing a bunch of words into the mailbox
     * and sending a [MailboxMessageValidRequest].
     *
     * @param mailbox the [SmackMailbox] for the word address calculation
     * @param dataPoint the [DataPoint] to write the data to
     * @param data the data to write into the [DataPoint]
     * @param encryptionKey the AES key for data encryption
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws InvalidKeyException if the given encryptionKey is not 16 Bytes long.
     * Only AES128 is supported.
     * @throws ProtocolException if the data couldn't be written to the [DataPoint]
     * @throws DataValidationException if the length of the given data
     * doesn't match the [DataPointType]
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun writeDataPoint(
        mailbox: SmackMailbox,
        dataPoint: DataPoint,
        data: ByteArray,
        encryptionKey: LockKey? = null
    ): List<SmackResponse>

    /**
     * Sends the "mailbox message valid" command,
     * which lets the hardware process the mailbox contents.
     *
     * @returns the response to this command
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws ResponseException if the command validation fails
     * @throws MailboxMessageValidResponseException if the response validation fails
     */
    suspend fun sendMailboxMessageValidCommand(): SmackResponse

    /**
     * Requests the firmware name as an ASCII String.
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     * @param encryptionDecryptionKey for encrypted communication
     *
     * @return the firmware name
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws InvalidKeyException if the given encryptionDecryptionKey is not 16 Bytes long.
     * Only AES128 is supported.
     * @throws ProtocolException if the data couldn't be read from the [DataPoint]
     * or if the read data was shorter than the expected data length
     * @throws IllegalArgumentException if a [DataPoint] with [DataPointType] [DataPointType.STRING]
     * or [DataPointType.ARRAY] is read without providing the length of the data to read
     * or if the provided dynamicDataToReadLength is 0
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getFirmwareName(mailbox: SmackMailbox, encryptionDecryptionKey: LockKey?): String

    /**
     * Requests the firmware version as a String.
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     * @param encryptionDecryptionKey for encrypted communication
     *
     * @return the firmware version
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws InvalidKeyException if the given encryptionDecryptionKey is not 16 Bytes long.
     * Only AES128 is supported.
     * @throws ProtocolException if the data couldn't be read from the [DataPoint]
     * or if the read data was shorter than the expected data length
     * @throws IllegalArgumentException if a [DataPoint] with [DataPointType] [DataPointType.STRING]
     * or [DataPointType.ARRAY] is read without providing the length of the data to read
     * or if the provided dynamicDataToReadLength is 0
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getFirmwareVersion(mailbox: SmackMailbox, encryptionDecryptionKey: LockKey?): String

    /**
     * Requests the UID/serial number of the chip.
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     *
     * @return the UID/serial number
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws ProtocolException if the data couldn't be read from the [DataPoint]
     * or if the read data was shorter than the expected data length
     * @throws IllegalArgumentException if a [DataPoint] with [DataPointType] [DataPointType.STRING]
     * or [DataPointType.ARRAY] is read without providing the length of the data to read
     * or if the provided dynamicDataToReadLength is 0
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     */
    suspend fun getUid(mailbox: SmackMailbox): ULong

    /**
     * Requests the [ChargeLevel] using the information of a [SmackMailbox].
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     * @param encryptionDecryptionKey for encrypted communication
     *
     * @return the current [ChargeLevel] of the given [SmackMailbox]
     *
     * @throws IllegalStateException if the smackClient is not connected
     * @throws InvalidKeyException if the given encryptionDecryptionKey is not 16 Bytes long.
     * Only AES128 is supported.
     * @throws ProtocolException if the data couldn't be read from the [DataPoint]
     * or if the read data was shorter than the expected data length
     * @throws IllegalArgumentException if a [DataPoint] with [DataPointType] [DataPointType.STRING]
     * or [DataPointType.ARRAY] is read without providing the length of the data to read
     * or if the provided dynamicDataToReadLength is 0
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws HeaderValidationException if the header flags from the response indicate an error
     * @throws ResponseException if the validation fails
     * @throws WrongKeyException when the firmware does not know the provided lockKey
     */
    suspend fun getChargeLevel(mailbox: SmackMailbox, encryptionDecryptionKey: LockKey): ChargeLevel

    /**
     * Calls one of the 16 app functions with the given index
     * and writes the the given data to the mailbox.
     * This includes sending a [MailboxMessageValidRequest] at the end
     * and reading the mailbox data afterwards.
     *
     * @param mailbox the [SmackMailbox] for word address calculation
     * @param index the function index - must be between 0 and 15
     * @param data the data to write into the mailbox - the size must be 64 bytes or less
     *
     * @returns the first 64 bytes from the mailbox as single words
     *
     * @throws IllegalArgumentException if the index is out of range (0-15)
     * or the data is larger then 64 bytes
     * @throws IllegalStateException if the smackClient is not connected
     * @throws SmackMailboxException if any internal word address can't be calculated
     * @throws ResponseException if the validation fails
     */
    suspend fun callAppFunction(
        mailbox: SmackMailbox,
        index: Byte,
        data: ByteArray
    ): List<ByteArray>
}
