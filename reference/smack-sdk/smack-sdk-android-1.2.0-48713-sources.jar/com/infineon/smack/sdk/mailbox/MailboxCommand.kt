package com.infineon.smack.sdk.mailbox

internal enum class MailboxCommand(val byte: Byte) {

    CALL_APP_FUNCTION(0x60.toByte())
}
