package com.infineon.smack.sdk.mailbox.datapoint

/**
 * DataPoint denotes an identification value and a [DataPointType].
 * This data type, its length and the data point value is used
 * to build a specific word for a data point request.
 */
interface DataPoint {

    /** The value identifying the data point */
    val value: UShort

    /** The [DataPointType] of this data point containing its length */
    val dataType: DataPointType

    /** The name of the datapoint */
    val name: String
}
