package com.infineon.smack.sdk.mailbox.datapoint

internal enum class DataPointAction {

    READ, WRITE
}
