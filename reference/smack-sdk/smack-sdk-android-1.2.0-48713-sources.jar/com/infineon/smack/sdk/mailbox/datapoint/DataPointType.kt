package com.infineon.smack.sdk.mailbox.datapoint

import kotlin.experimental.or

/**
 * Each [DataPoint] is related to a data point type.
 * A DataPointType has a value for identifying the type and a specific length.
 */
@Suppress("MagicNumber")
enum class DataPointType(
    private val intValue: Int,
    private val intLength: Int? = null
) {
    BOOL(0x01, 1),
    INT8(0x02, 1),
    UINT8(0x03, 1),
    INT16(0x04, 2),
    UINT16(0x05, 2),
    INT32(0x06, 4),
    UINT32(0x07, 4),
    INT64(0x08, 8),
    UINT64(0x09, 8),
    /**
     * The ARRAY DataPointType has no length. So the length must be provided,
     * when reading a data point of this type.
     */
    ARRAY(0x10),
    /**
     * The STRING DataPointType has no length. So the length must be provided,
     * when reading a data point of this type.
     */
    STRING(0x11);

    /** The Byte value used for reading a [DataPoint] of this type */
    val readValue: Byte
        get() = intValue.toByte()

    /** The Byte value used for writing a [DataPoint] of this type */
    val writeValue: Byte
        get() = WRITE_FLAG or readValue

    /** The Byte value for the length of this type in Bytes */
    val length: Byte?
        get() = intLength?.toByte()

    companion object {

        private const val WRITE_FLAG = 0x80.toByte()
    }
}
