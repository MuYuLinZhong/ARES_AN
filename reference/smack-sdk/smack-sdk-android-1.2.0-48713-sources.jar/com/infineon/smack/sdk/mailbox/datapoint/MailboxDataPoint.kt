package com.infineon.smack.sdk.mailbox.datapoint

import com.infineon.smack.sdk.nfc.communication.ByteArrayWordExtensions.halfWordToUShort

/**
 * MailboxDataPoint summarizes all data points, that are not tied to a specific hardware
 * but can be used on any SmAcK compatible hardware.
 */
enum class MailboxDataPoint(
    override val value: UShort,
    override val dataType: DataPointType
) : DataPoint {

    SMACK_FLAGS(byteArrayOf(0x00.toByte(), 0x00.toByte()).halfWordToUShort(), DataPointType.UINT32),

    /** The raw charge state of the capacitor on the NFC hardware */
    CHARGE_RAW(byteArrayOf(0x00.toByte(), 0x10.toByte()).halfWordToUShort(), DataPointType.UINT16),

    /** The raw charge threshold of the capacitor on the NFC hardware */
    CHARGE_RAW_THRESHOLD(
        byteArrayOf(0x00.toByte(), 0x11.toByte()).halfWordToUShort(),
        DataPointType.UINT16
    ),

    /** The charge state of the capacitor on the NFC hardware in percent */
    CHARGE_PERCENT(
        byteArrayOf(0x00.toByte(), 0x12.toByte()).halfWordToUShort(),
        DataPointType.UINT8
    ),
    GLOBAL_COUNTER(
        byteArrayOf(0xE1.toByte(), 0x00.toByte()).halfWordToUShort(),
        DataPointType.UINT32
    ),

    /** The temperature detected from the sensor on the NFC hardware in degrees Celsius */
    TEMPERATURE(byteArrayOf(0xE1.toByte(), 0x02.toByte()).halfWordToUShort(), DataPointType.INT32),

    /** The SmAcK firmware version */
    FIRMWARE_VERSION(
        byteArrayOf(0x00.toByte(), 0x01.toByte()).halfWordToUShort(),
        DataPointType.UINT32
    ),

    /** The SmAcK firmware string */
    FIRMWARE_NAME(
        byteArrayOf(0x00.toByte(), 0x03.toByte()).halfWordToUShort(),
        DataPointType.STRING
    ),

    /** The serial number of the chip (7 bytes) */
    UID(byteArrayOf(0x00.toByte(), 0x04.toByte()).halfWordToUShort(), DataPointType.UINT64),

    /** A 32 bit (4 Byte) data point for testing purposes */
    SCRATCH32(byteArrayOf(0xF0.toByte(), 0x00.toByte()).halfWordToUShort(), DataPointType.UINT32),

    /** A 16 bit (2 Byte) data point for testing purposes */
    SCRATCH16(byteArrayOf(0xF0.toByte(), 0x01.toByte()).halfWordToUShort(), DataPointType.UINT16),

    /** An 8 bit (1 Byte) data point for testing purposes */
    SCRATCH8(byteArrayOf(0xF0.toByte(), 0x02.toByte()).halfWordToUShort(), DataPointType.UINT8),

    /**
     * A string data point of dynamic length for testing purposes.
     * This is only for testing as long as there is no counterpart in the firmware.
     */
    SCRATCH_STRING(
        byteArrayOf(0xF0.toByte(), 0x03.toByte()).halfWordToUShort(),
        DataPointType.STRING
    )
}
