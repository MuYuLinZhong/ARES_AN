package com.infineon.smack.sdk.mailbox.request.descriptor

import com.infineon.smack.sdk.application.lock.key.LockKey
import com.infineon.smack.sdk.mailbox.datapoint.DataPoint

internal data class DataPointReadRequestDescriptor(
    override val dataPoint: DataPoint,
    private val bufferSize: Byte?,
    override val encryptionKey: LockKey?,
) : DataPointRequestDescriptor {

    override val dataToWrite: ByteArray? = null
    override val dataToReadLength = bufferSize ?: dataPoint.dataType.length
}
