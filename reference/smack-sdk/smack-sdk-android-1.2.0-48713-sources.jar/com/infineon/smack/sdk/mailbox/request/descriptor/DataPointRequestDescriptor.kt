package com.infineon.smack.sdk.mailbox.request.descriptor

import com.infineon.smack.sdk.application.lock.key.LockKey
import com.infineon.smack.sdk.mailbox.datapoint.DataPoint
import com.infineon.smack.sdk.mailbox.datapoint.DataPointAction

internal interface DataPointRequestDescriptor {

    val dataPoint: DataPoint
    val dataToWrite: ByteArray?
    val dataToReadLength: Byte?
    val encryptionKey: LockKey?

    val dataToWriteLength: Byte?
        get() = dataToWrite?.size?.toByte()

    val dataLengthToReadOrWrite: Byte
        get() = requireNotNull(dataToWriteLength ?: dataToReadLength)

    val dataPointAction: DataPointAction
        get() = dataToWrite?.let { DataPointAction.WRITE } ?: DataPointAction.READ
}
