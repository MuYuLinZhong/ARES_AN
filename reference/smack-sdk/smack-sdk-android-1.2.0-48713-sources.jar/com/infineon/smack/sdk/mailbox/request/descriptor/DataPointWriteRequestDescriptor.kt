package com.infineon.smack.sdk.mailbox.request.descriptor

import com.infineon.smack.sdk.application.lock.key.LockKey
import com.infineon.smack.sdk.mailbox.datapoint.DataPoint

internal data class DataPointWriteRequestDescriptor(
    override val dataPoint: DataPoint,
    override val dataToWrite: ByteArray?,
    override val encryptionKey: LockKey?,
) : DataPointRequestDescriptor {

    override val dataToReadLength: Byte? = null

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as DataPointWriteRequestDescriptor

        if (dataPoint != other.dataPoint) return false
        if (dataToWrite != null) {
            if (other.dataToWrite == null) return false
            if (!dataToWrite.contentEquals(other.dataToWrite)) return false
        } else if (other.dataToWrite != null) return false
        if (encryptionKey != other.encryptionKey) return false
        if (dataToReadLength != other.dataToReadLength) return false

        return true
    }

    override fun hashCode(): Int {
        var result = dataPoint.hashCode()
        result = 31 * result + (dataToWrite?.contentHashCode() ?: 0)
        result = 31 * result + (encryptionKey?.hashCode() ?: 0)
        result = 31 * result + (dataToReadLength ?: 0)
        return result
    }
}
