package com.infineon.smack.sdk.nfc

import android.app.Activity
import android.app.PendingIntent
import android.content.IntentFilter

interface NfcAdapterWrapper {

    fun enableForegroundDispatch(
        activity: Activity,
        intent: PendingIntent,
        filters: Array<IntentFilter>,
        techLists: Array<Array<String>>
    ): Unit?

    fun disableForegroundDispatch(activity: Activity): Unit?
}
