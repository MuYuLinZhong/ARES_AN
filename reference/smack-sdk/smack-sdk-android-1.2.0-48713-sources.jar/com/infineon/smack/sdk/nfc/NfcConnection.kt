package com.infineon.smack.sdk.nfc

interface NfcConnection {

    val isConnected: Boolean

    fun connect()

    fun disconnect()

    fun sendByteArray(command: ByteArray): ByteArray
}
