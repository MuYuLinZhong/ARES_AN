package com.infineon.smack.sdk.smack

import com.infineon.smack.sdk.smack.exception.ProtocolException
import com.infineon.smack.sdk.smack.exception.ResponseException
import com.infineon.smack.sdk.smack.request.RequestList
import com.infineon.smack.sdk.smack.request.SmackRequest
import com.infineon.smack.sdk.smack.response.SmackResponse

/**
 * The SmackApi can be used to send single [SmackRequest]s or a prepared [List] of [SmackRequest]s.
 * But it can't be used on it's own, because it has no Flow to observe when a tag is connected.
 *
 * Use the [com.infineon.smack.sdk.mailbox.MailboxApi] which provides a SmackApi.
 * Observe the mailbox as described in [com.infineon.smack.sdk.mailbox.MailboxApi].
 * As soon as the [com.infineon.smack.sdk.mailbox.MailboxApi] is available, the SmackApi from the
 * MailboxApi can be used to send single [SmackRequest]s or a prepared [List] of [SmackRequest]s.
 *
 * @see [com.infineon.smack.sdk.mailbox.SmackMailboxApi]
 */
interface SmackApi {

    /**
     * Sends a single [SmackRequest].
     *
     * @param request the [SmackRequest] to send
     * @return the [SmackResponse]
     * @throws ProtocolException if the response is empty
     * @throws ResponseException if the validation fails
     */
    suspend fun sendRequest(request: SmackRequest): SmackResponse

    /**
     * Uses [sendRequest] to send all [SmackRequest]s held by the given [RequestList].
     *
     * @param requests the [RequestList] holding all [SmackRequest]s to send
     * @return the [List] of [SmackResponse]s from all sent [SmackRequest]s
     * @throws ProtocolException on the first [SmackRequest] that can't be processed
     * @throws ResponseException if the validation fails
     *
     * @see [sendRequest]
     */
    suspend fun sendRequests(requests: List<SmackRequest>): List<SmackResponse>
}
