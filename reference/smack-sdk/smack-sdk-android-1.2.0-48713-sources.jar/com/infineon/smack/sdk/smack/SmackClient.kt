package com.infineon.smack.sdk.smack

import com.infineon.smack.sdk.log.SmackLogger
import com.infineon.smack.sdk.nfc.NfcConnection
import kotlinx.coroutines.flow.Flow

/**
 * A SmackClient can connect to a [NfcConnection] and then send byte arrays to that connection.
 */
interface SmackClient {

    /** A logger for logging the transferred bytes */
    val nfcLogger: SmackLogger

    /** Indicates if the client is connected. */
    val isConnected: Flow<Boolean>

    /**
     * Should be called whenever there is a new Tag discovered [NfcConnection].
     *
     * @param nfcConnection the [NfcConnection] to connect to
     */
    suspend fun onNewConnection(nfcConnection: NfcConnection)

    /**
     * Sends the given bytes to the connected [NfcConnection].
     *
     * @param command the byte array to send
     *
     * @return the response as byte array
     *
     * @throws IllegalStateException if no [NfcConnection] is connected
     */
    suspend fun sendByteArray(command: ByteArray): ByteArray
}
