package com.infineon.smack.sdk.smack.command

import com.infineon.smack.sdk.smack.request.MailboxMessageValidRequest
import com.infineon.smack.sdk.smack.request.ReadMailboxAddressSmackRequest
import com.infineon.smack.sdk.smack.request.ReadMailboxLengthSmackRequest
import com.infineon.smack.sdk.smack.request.ReadWordSmackRequest
import com.infineon.smack.sdk.smack.request.WriteWordSmackRequest

/**
 * Smack commands are used for active communication with the smack protocol and the mailbox.
 */
enum class SmackCommand(val value: Byte) {

    /**
     * Starts the SmAcK protocol. This must be used before any of the other commands.
     */
    START_SMACK_PROTOCOL(0x47.toByte()),

    /**
     * Sends a mailbox message.
     * Possible values:
     *  0: read mailbox address
     *  1: read mailbox size
     *  2: indicates that the mailbox content is a complete and valid request and can be processed
     *
     *  @see ReadMailboxAddressSmackRequest
     *  @see ReadMailboxLengthSmackRequest
     *  @see MailboxMessageValidRequest
     */
    SEND_MESSAGE(0x60.toByte()),

    /**
     * Writes a word to the mailbox. The data must contain a valid mailbox word address.
     *
     * @see WriteWordSmackRequest
     */
    WRITE_WORD(0x70.toByte()),

    /**
     * Reads a word from the mailbox. The data must contain a valid mailbox word address.
     *
     * @see ReadWordSmackRequest
     */
    READ_WORD(0x80.toByte()),
}
