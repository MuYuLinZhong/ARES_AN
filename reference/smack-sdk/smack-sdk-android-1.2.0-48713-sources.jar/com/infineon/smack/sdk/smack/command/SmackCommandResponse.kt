package com.infineon.smack.sdk.smack.command

import com.infineon.smack.sdk.smack.response.SmackResponse

/**
 * This enum represents the acknowledgement or error code from a [SmackResponse]
 * (from the first Byte). It contains the related [SmackCommand],
 * so it can be compared or validated.
 */
enum class SmackCommandResponse(
    /** The raw value of this command response */
    val value: Byte,
    /** The related [SmackCommand] if applicable */
    val relatedSmackCommand: SmackCommand? = null
) {

    /** The acknowledgment for the [SmackCommand.SEND_MESSAGE] */
    ACK_SEND_MESSAGE(0x60.toByte(), SmackCommand.SEND_MESSAGE),

    /** The acknowledgment for the [SmackCommand.WRITE_WORD] */
    ACK_WRITE_WORD(0x70.toByte(), SmackCommand.WRITE_WORD),

    /** The acknowledgment for the [SmackCommand.READ_WORD] */
    ACK_READ_WORD(0x80.toByte(), SmackCommand.READ_WORD),

    /** The error code for a CRC error */
    ERROR_RECEIVING_CRC(0xAA.toByte()),

    /** The error code for a CRC or parity error */
    ERROR_RECEIVING_CRC_OR_PARITY(0xA5.toByte()),

    /** The error code for a read protected address */
    ERROR_READ_PROTECTED(0xC0.toByte()),

    /** The error code for a write protected address */
    ERROR_WRITE_PROTECTED(0xD0.toByte()),

    /** The error code for a misaligned address */
    ERROR_ADDRESS_MISALIGNED(0xDD.toByte()),

    /** The error code for an unknown command */
    ERROR_UNKNOWN_COMMAND(0xAF.toByte());

    companion object {

        /**
         * @return the [SmackCommandResponse] matching the given byte
         */
        fun fromByte(byte: Byte): SmackCommandResponse? =
            values().find { commandResponse -> commandResponse.value == byte }
    }
}
