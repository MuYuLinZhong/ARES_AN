package com.infineon.smack.sdk.smack.request

interface RequestList {

    val requests: List<SmackRequest>
}
