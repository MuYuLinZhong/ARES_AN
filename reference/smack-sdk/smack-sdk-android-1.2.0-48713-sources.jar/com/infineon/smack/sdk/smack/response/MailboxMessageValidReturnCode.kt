package com.infineon.smack.sdk.smack.response

import com.infineon.smack.sdk.nfc.communication.asHexToByteArray

/**
 * This enum represents the possible return codes
 * from a response to a "mailbox message valid" command.
 */
enum class MailboxMessageValidReturnCode(val responseWord: ByteArray) {

    /** The valid return code for a "mailbox message valid" command */
    CALL_APP_FUNCTION("600000".asHexToByteArray()),

    /** The error return code, if the internal function couldn't be called */
    CALL_APP_FUNCTION_ERROR("60A000".asHexToByteArray()),

    /** The error return code, if the word couldn't be written */
    WRITE_WORD_ERROR("A0000011".asHexToByteArray()),

    /** The error return code, if the half word couldn't be written */
    WRITE_HALF_WORD_ERROR("A0000012".asHexToByteArray()),

    /** The error return code, if the byte couldn't be written */
    WRITE_BYTE_ERROR("A0000013".asHexToByteArray()),

    /** The error return code, if the word couldn't be read */
    READ_WORD_ERROR("A0000014".asHexToByteArray()),

    /** The error return code, if the half word couldn't be read */
    READ_HALF_WORD_ERROR("A0000015".asHexToByteArray()),

    /** The error return code, if the byte couldn't be read */
    READ_BYTE_ERROR("A0000016".asHexToByteArray());

    companion object {

        /**
         * @return the MailboxMessageValidReturnCode matching the word from the response
         */
        fun fromResponse(response: SmackResponse): MailboxMessageValidReturnCode? =
            values().find { returnCode ->
                returnCode.responseWord.contentEquals(response.word)
            } ?: findCallAppFunctionFromResponse(response)

        private fun findCallAppFunctionFromResponse(
            response: SmackResponse
        ): MailboxMessageValidReturnCode? =
            response.word?.firstThreeBytes()?.let { firstThreeBytesFromResponseWord ->
                findCallAppFunctionFromThreeBytes(firstThreeBytesFromResponseWord)
            }

        private fun findCallAppFunctionFromThreeBytes(threeBytes: ByteArray) =
            listOf(CALL_APP_FUNCTION, CALL_APP_FUNCTION_ERROR)
                .find { callAppFunctionReturnCode ->
                    threeBytes.contentEquals(callAppFunctionReturnCode.responseWord)
                }

        @Suppress("MagicNumber")
        private fun ByteArray.firstThreeBytes(): ByteArray? =
            takeIf { it.size >= 3 }?.slice(0..2)?.toByteArray()
    }
}
