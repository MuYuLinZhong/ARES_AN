package com.infineon.smack.sdk.smack.response

import com.infineon.smack.sdk.nfc.communication.toHexString
import com.infineon.smack.sdk.smack.SmackApi
import com.infineon.smack.sdk.smack.command.SmackByteArrayExtensions.getReturnCode
import com.infineon.smack.sdk.smack.command.SmackByteArrayExtensions.getSmackResponseWord
import com.infineon.smack.sdk.smack.command.SmackCommandResponse
import com.infineon.smack.sdk.smack.exception.ProtocolException

/**
 * This class represents a response to sending Bytes to a NFC tag using the SmAcK protocol.
 * @see SmackApi.sendRequest
 */
data class SmackResponse(
    /** The raw command response (first Byte) */
    val rawCommandResponse: Byte,
    /** The word from the response */
    val word: ByteArray?
) {

    /** The [SmackCommandResponse] parsed from the [rawCommandResponse] if possible */
    val commandResponse: SmackCommandResponse?
        get() = SmackCommandResponse.fromByte(rawCommandResponse)

    // Override needed because data classes do not compare ByteArrays correctly  https://medium.com/asos-techblog/what-you-didnt-know-about-arrays-in-kotlin-d3b20337e4
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false

        other as SmackResponse

        if (rawCommandResponse != other.rawCommandResponse) return false
        if (!word.contentEquals(other.word)) return false

        return true
    }

    override fun hashCode(): Int {
        var result = rawCommandResponse.hashCode()
        result = 31 * result + word.contentHashCode()
        return result
    }

    override fun toString(): String {
        return "SmackResponse(rawCommandResponse=${byteArrayOf(rawCommandResponse).toHexString()}" +
            ", word=${word?.toHexString() ?: "null"})"
    }

    companion object {

        /**
         * Creates a [SmackResponse] from the given [ByteArray].
         *
         * @param byteArray the [ByteArray] to create the [SmackResponse] from
         *
         * @throws ProtocolException if the given byteArray is empty
         */
        fun fromByteArray(byteArray: ByteArray): SmackResponse =
            SmackResponse(byteArray.getReturnCode(), byteArray.getSmackResponseWord())
    }
}
